Notice courte :

Les fichiers correspondant à la première partie du projet, c’est-à-dire au pré-traitement et à l’envoi des données sont disponibles dans le dossier Partie 1. 
Les fichiers correspondant à la seconde partie, c’est-à-dire à la récupération, au post-traitement et à l’affichage des données sont disponibles dans le dossier Partie 2.

L’appel des fonctions correspondant à la partie 1 est disponible dans le fichier « part1.py » (en commentaire car une partie doit être exécutée sur Matlab).

Les fonctions liées à la partie 2 sont appelées par l’interface utilisateur. 
Pour lancer l’interface, il faut se positionner dans le dossier « Partie 2 » et appeler la commande « flask run » dans un terminal python. 
Il faut ensuite coller le lien affiché par le terminal dans un navigateur.
